BOPAL takes two arguments, the newick tree file and the folder containing the sequence files.
As an example, to run BOPAL on the Bacillus data set use the following command:

python main.py tree.dnd Bacillus_Test